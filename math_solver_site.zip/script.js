function solveEquation() {
    let eq = document.getElementById("equation").value.replace(/\s+/g, "");
    let resultBox = document.getElementById("result");

    if (!eq.includes("=")) {
        resultBox.innerHTML = "❌ يجب أن تحتوي المعادلة على علامة =";
        return;
    }

    try {
        const sides = eq.split("=");

        let left = parseEquation(sides[0]);
        let right = parseEquation(sides[1]);

        let a = left.a - right.a;
        let b = left.b - right.b;
        let c = left.c - right.c;

        if (a === 0) {
            if (b === 0) {
                resultBox.innerHTML = c === 0 ? "∞ حلول (متطابقة)" : "لا يوجد حل";
                return;
            }
            let x = -c / b;
            resultBox.innerHTML = "الحل: x = " + x;
            return;
        }

        let d = b*b - 4*a*c;
        if (d < 0) {
            resultBox.innerHTML = "❌ لا يوجد جذور حقيقية";
            return;
        }

        let x1 = (-b + Math.sqrt(d)) / (2*a);
        let x2 = (-b - Math.sqrt(d)) / (2*a);

        resultBox.innerHTML = `
            <div>الحل 1: x = ${x1}</div>
            <div>الحل 2: x = ${x2}</div>
        `;

    } catch(err) {
        resultBox.innerHTML = "❌ خطأ في كتابة المعادلة";
    }
}

function parseEquation(eq) {
    let a = 0, b = 0, c = 0;

    eq = eq.replace(/-/g, "+-");
    let terms = eq.split("+");

    terms.forEach(t => {
        if (t === "") return;

        if (t.includes("x^2")) {
            let coef = t.replace("x^2", "");
            a += parseFloat(coef || 1);
        }
        else if (t.includes("x")) {
            let coef = t.replace("x", "");
            b += parseFloat(coef || 1);
        }
        else {
            c += parseFloat(t);
        }
    });

    return {a, b, c};
}
